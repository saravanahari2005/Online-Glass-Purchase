package com.example.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.model.Specs;
import com.example.service.SpecsService;
import java.util.List;

@RestController
@RequestMapping("/api/specs")
@CrossOrigin("*")
public class SpecsController {
    @Autowired
    private SpecsService service;

    @GetMapping
    public List<Specs> getAll() {
        return service.getAllSpecs();
    }

    @PostMapping
    public Specs addSpecs(@RequestBody Specs specs) {
        return service.addSpecs(specs);
    }
}
