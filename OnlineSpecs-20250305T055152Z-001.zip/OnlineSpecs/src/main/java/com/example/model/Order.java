package com.example.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String address;
    private String paymentMethod;

    @ElementCollection
    private List<String> items; // Stores product details

    // Getters and Setters
}
