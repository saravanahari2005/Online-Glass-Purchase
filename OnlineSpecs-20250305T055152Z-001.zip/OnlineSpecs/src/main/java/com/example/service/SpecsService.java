package com.example.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.model.Specs;
import com.example.repository.SpecsRepository;
import java.util.List;

@Service
public class SpecsService {
    @Autowired
    private SpecsRepository repository;

    public List<Specs> getAllSpecs() {
        return repository.findAll();
    }

    public Specs addSpecs(Specs specs) {
        return repository.save(specs);
    }
}

