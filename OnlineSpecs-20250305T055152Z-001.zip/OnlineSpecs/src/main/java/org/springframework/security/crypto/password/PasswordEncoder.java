package org.springframework.security.crypto.password;

public class PasswordEncoder {

}
