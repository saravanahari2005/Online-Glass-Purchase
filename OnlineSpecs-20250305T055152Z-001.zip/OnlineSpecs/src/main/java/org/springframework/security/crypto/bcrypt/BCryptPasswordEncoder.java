package org.springframework.security.crypto.bcrypt;

public class BCryptPasswordEncoder {

}
