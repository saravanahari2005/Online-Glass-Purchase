// Function to fetch spectacles and display them as cards
async function fetchSpecs() {
    try {
        let response = await fetch("http://localhost:8080/api/specs");
        if (!response.ok) throw new Error("Failed to fetch data");

        let data = await response.json();
        let container = document.getElementById("specsContainer");

        data.forEach(spec => {
            let card = document.createElement("div");
            card.className = "col-md-4 mb-4";
            card.innerHTML = `
                <div class="card">
                    <img src="spectacles.jpg" class="card-img-top" alt="Spectacle">
                    <div class="card-body text-center">
                        <h5 class="card-title">${spec.brand} - ${spec.model}</h5>
                        <p class="card-text">Price: ₹${spec.price}</p>
                        <button class="btn btn-primary" onclick="addToCart(${spec.id}, '${spec.brand}', '${spec.model}', ${spec.price})">Add to Cart</button>
                    </div>
                </div>
            `;
            container.appendChild(card);
        });

    } catch (error) {
        console.error("Error:", error);
    }
}

// Function to add items to the cart (stored in localStorage)
function addToCart(id, brand, model, price) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    let item = { id, brand, model, price };
    cart.push(item);

    localStorage.setItem("cart", JSON.stringify(cart));

    updateCartCount();
    alert("Item added to cart!");
}

// Function to update cart item count in the navbar
function updateCartCount() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    document.getElementById("cartCount").innerText = cart.length;
}

// Initialize cart count on page load
window.onload = function() {
    fetchSpecs();
    updateCartCount();
};
